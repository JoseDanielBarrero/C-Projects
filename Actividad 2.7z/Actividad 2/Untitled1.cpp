#include <iostream>
#include <conio.h>

using namespace std;

int otro()
{
	cout<<i;
}
int main()
{
	

	int i;
	for(int i=1; i<3;i++)
	{
		cout<<i<<endl;
	}
	cout<<i;
	otro();
	return 0;
}
